package Clases.empelado;

public class Medico {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
