package Clases.empelado;

public class EmpleadoEventual {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
